function [ yyy,yyy1,yyy2] = TVspread_Main( CPI_AC,WTI, RAC_WTI,BRENT,spotheat,spotgas,jx,h,nburn )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
            %Finfd the number of rows before the last obs
            %jx=12;
            [NAN_1, ~] = find(isnan(CPI_AC(:,jx)));
            ind = NAN_1(1,1)-1;clear NAN_1                                    % Indicates length of intial real-time sample (up to 1991.12+jx-12)
             
            % Create data in column format 
            rpo=100*WTI(1:ind,jx)./CPI_AC(1:ind,jx);      % Real oil price (nominal WTI for imports deflated by US CPI)
            yy=rpo(2:end,1);

            rac=100*RAC_WTI(1:ind,jx)./CPI_AC(1:ind,jx);  % Real oil price (nominal RAC for imports deflated by US CPI)
            yy1=rac(2:end,1);


            brent=100*BRENT(1:ind,jx)./CPI_AC(1:ind,jx);  % Real oil price (nominal RAC for imports deflated by US CPI)
            yy2=brent(2:end,1);

            t=length(yy1); 

            % Define regressors for 1986:07+ in terms of dollars/barrel prices
            %Whereas crude oil prices are reported in U.S. dollars per barrel, 
            %gasoline and heating oil prices are reported in cents per gallon. 
            %All product prices are transformed to dollars per barrel, 
            %which involves multiplying each product price by 42 gallons/barrel 
            %and dividing by 100 cents/dollar.
            spotheatrt=log(spotheat(228-66+1:ind,:)*0.42); 
            spotgasrt=log(spotgas(228-66+1:ind,:)*0.42); 
            spotoilrt=log(WTI(228-66+1:ind,end));
            spotoilrt_brent=log(BRENT(228-66+1:ind,end));
            heatspreadrt=spotheatrt-spotoilrt;
            gasspreadrt=spotgasrt-spotoilrt; 
            heatspreadrt_brent=spotheatrt-spotoilrt_brent;
            gasspreadrt_brent=spotgasrt-spotoilrt_brent;     
            inflrt=log(CPI_AC(228-66+2:ind,jx))-log(CPI_AC(228-66+1:ind-1,jx)); 

            % Create ex post-revised real price of oil (last vintage in file)
            x=100*WTI(1:ind+h,end)./CPI_AC(1:ind+h,end);          % Real oil price (nominal WTI deflated by US CPI)
            x=x(2:end,1);

            x1=100*RAC_WTI(1:ind+h,end)./CPI_AC(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
            x1=x1(2:end,1);

            x2=100*BRENT(1:ind+h,end)./CPI_AC(1:ind+h,end);     % Real oil price (nominal BRENT for imports deflated by US CPI)
            x2=x2(2:end,1);

            % Generate h-step ahead futures-based forecast  
            yy=[yy; zeros(h,1)];
            yy1=[yy1; zeros(h,1)];
            yy2=[yy2; zeros(h,1)];    
            YY=spotoilrt(h+1:end,1)-spotoilrt(1:end-h,1);
            YY_brent=spotoilrt_brent(h+1:end,1)-spotoilrt_brent(1:end-h,1);    
            XX=[heatspreadrt(1:end-h,1) gasspreadrt(1:end-h,1)];
            XX_brent=[heatspreadrt_brent(1:end-h,1) gasspreadrt_brent(1:end-h,1)];
            %alpha and beta time-varying
            [bhat,q,r]=estimate_bt_final(YY,XX,nburn);
            [bhat_brent,q_brent,r_brent]=estimate_bt_final(YY_brent,XX_brent,nburn);
            clear XX YY


             yyy=zeros(size(bhat,3),1);
             yyy1=zeros(size(bhat,3),1);
             yyy2=zeros(size(bhat_brent,3),1);


             for jj=1:size(bhat,3)
                 bb=squeeze(bhat(:,end,jj));
                 bb_brent=squeeze(bhat_brent(:,end,jj));
                 for jy=2:h
                     bb(:,jy)=bb(:,jy-1)+real(sqrtm(q(:,:,jj)))*randn(size(bhat,1),1);
                     bb_brent(:,jy)=bb_brent(:,jy-1)+real(sqrtm(q_brent(:,:,jj)))*randn(size(bhat_brent,1),1);
                 end
                yyy(jj,1)=yy(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                                     +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
                yyy1(jj,1)=yy1(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                                     +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
                yyy2(jj,1)=yy2(t,1)*exp(bb_brent(1,h)*heatspreadrt(end,1) ...
                                     +bb_brent(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r_brent(jj,1)))-((1+mean(inflrt))^h-1));
                clear bb bb_brent
             end    

end

