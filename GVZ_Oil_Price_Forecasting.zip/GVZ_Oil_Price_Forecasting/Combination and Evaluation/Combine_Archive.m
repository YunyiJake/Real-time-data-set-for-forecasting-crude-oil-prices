%% Out-of-sample observations
clear all;
clc;
warning('off','all')

load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision
CPI_AC=[nan(546,11) CPI];
RAC_WTI=[nan(546,11) RAC];
WTI=[nan(546,11) WTI];
clearvars -except RAC_WTI CPI_AC WTI BRENT
oil_prices.WTI=WTI;
oil_prices.RAC=RAC_WTI;
oil_prices.BRENT=BRENT;
PriceName=fieldnames(oil_prices);
%Ex-post obs
for Nmodel=1:3
    %Space for the observations
        space=NaN(size(oil_prices.(PriceName{Nmodel}),1)-228-6,24);
        ind=228;
    for Nprice=1:size(oil_prices.(PriceName{Nmodel}),1)-228-6 %6: lag of data avilability
        for Nhorizon=1:24
            
                if Nprice+Nhorizon>size(oil_prices.(PriceName{Nmodel}),1)-228-6+1
                else 
%                     %Final vintage 2018:06
%                     space(Nprice,Nhorizon)=oil_prices.(PriceName{Nmodel})(ind+Nhorizon,end);
%                     CPI(Nprice,Nhorizon)=CPI_AC(ind+Nhorizon,end);
                    %Final vintage: 2012:03-2017:06
                    space(Nprice,Nhorizon)=oil_prices.(PriceName{Nmodel})(ind+Nhorizon,267);
                    CPI(Nprice,Nhorizon)=CPI_AC(ind+Nhorizon,267);
                    if ind+Nhorizon>483
                        space(Nprice,Nhorizon)=oil_prices.(PriceName{Nmodel})(ind+Nhorizon,267+ind+Nhorizon-483);
                        CPI(Nprice,Nhorizon)=CPI_AC(ind+Nhorizon,267+ind+Nhorizon-483);
                    end   
                end

        end
        ind=ind+1;
    end
    Obs.(PriceName{Nmodel})=100*space./CPI;
end
clearvars -except Obs oil_prices PriceName

%==========================================================================
%% Loading all forecasts
load('Constant_forecasts.mat')
Wiki=0;
load('Future_Forecasts.mat')
load('GasolineForecasts.mat')
load('PCOM_Forecasts.mat')
load('TVspread_Forecasts.mat')
load('VARforecasts.mat')
Forecasts.constant=ConstantForecasts;
Forecasts.CRB=PCOM_forecast;
Forecasts.futures=Future_forecasts;
Forecasts.GasOline=GasolineForecasts;
Forecasts.TVspread=TVforecasts;
Forecasts.VAR=VARforecasts;
ModelName=fieldnames(Forecasts);
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});
for Nmodel=1:6
    for Nprice=1:3
    for Nhorizon=1:24
        if Nmodel==1
            if Nhorizon==1
            forecasts1.(ModelName{Nmodel}).(PriceName{Nprice})(:,Nhorizon)=Forecasts.(ModelName{Nmodel}).(Mh{Nhorizon}).(PriceName{Nprice});
            else
            forecasts1.(ModelName{Nmodel}).(PriceName{Nprice})(:,Nhorizon)=[Forecasts.(ModelName{Nmodel}).(Mh{Nhorizon}).(PriceName{Nprice})(1:end-Nhorizon+1,1); NaN(Nhorizon-1,1)];
            end
        else
            if Nhorizon==1
            forecasts1.(ModelName{Nmodel}).(PriceName{Nprice})(:,Nhorizon)=Forecasts.(ModelName{Nmodel}).(Mh{Nhorizon}).(PriceName{Nprice});
            else
            forecasts1.(ModelName{Nmodel}).(PriceName{Nprice})(:,Nhorizon)=[Forecasts.(ModelName{Nmodel}).(Mh{Nhorizon}).(PriceName{Nprice}); NaN(Nhorizon-1,1)];
            end            
        end
    end
    end
end
clear Forecasts
Forecasts=forecasts1;  
clearvars -except Obs oil_prices PriceName Forecasts ModelName Mh
%==========================================================================
%% Kilian's 6 model combination
%Forecasts
K_forecasts.WTI.constant= Forecasts.constant.WTI;
K_forecasts.WTI.CRB=Forecasts.CRB.WTI;
K_forecasts.WTI.futures=Forecasts.futures.WTI;
K_forecasts.WTI.GasOline=Forecasts.GasOline.WTI;
K_forecasts.WTI.TVspread=Forecasts.TVspread.WTI;
K_forecasts.WTI.VAR=Forecasts.VAR.WTI;
K_forecasts.RAC.constant= Forecasts.constant.RAC;
K_forecasts.RAC.CRB=Forecasts.CRB.RAC;
K_forecasts.RAC.futures=Forecasts.futures.RAC;
K_forecasts.RAC.GasOline=Forecasts.GasOline.RAC;
K_forecasts.RAC.TVspread=Forecasts.TVspread.RAC;
K_forecasts.RAC.VAR=Forecasts.VAR.RAC;
K_forecasts.BRENT.constant= Forecasts.constant.BRENT;
K_forecasts.BRENT.CRB=Forecasts.CRB.BRENT;
K_forecasts.BRENT.futures=Forecasts.futures.BRENT;
K_forecasts.BRENT.GasOline=Forecasts.GasOline.BRENT;
K_forecasts.BRENT.TVspread=Forecasts.TVspread.BRENT;
K_forecasts.BRENT.VAR=Forecasts.VAR.BRENT;
Prices=fieldnames(K_forecasts);
for Nmodel=1:3
    for Nprice=1:6
        e.(ModelName{Nprice}).(PriceName{Nmodel})=Forecasts.(ModelName{Nprice}).(PriceName{Nmodel})- Obs.(PriceName{Nmodel});
    end
end

% SE
for Nmodel=1:3
    for Nprice=1:6
        se.(ModelName{Nprice}).(PriceName{Nmodel})=e.(ModelName{Nprice}).(PriceName{Nmodel}).^2;
    end
end
K_se.WTI.constant= se.constant.WTI;
K_se.WTI.CRB=se.CRB.WTI;
K_se.WTI.futures=se.futures.WTI;
K_se.WTI.GasOline=se.GasOline.WTI;
K_se.WTI.TVspread=se.TVspread.WTI;
K_se.WTI.VAR=se.VAR.WTI;
K_se.RAC.constant= se.constant.RAC;
K_se.RAC.CRB=se.CRB.RAC;
K_se.RAC.futures=se.futures.RAC;
K_se.RAC.GasOline=se.GasOline.RAC;
K_se.RAC.TVspread=se.TVspread.RAC;
K_se.RAC.VAR=se.VAR.RAC;
K_se.BRENT.constant= se.constant.BRENT;
K_se.BRENT.CRB=se.CRB.BRENT;
K_se.BRENT.futures=se.futures.BRENT;
K_se.BRENT.GasOline=se.GasOline.BRENT;
K_se.BRENT.TVspread=se.TVspread.BRENT;
K_se.BRENT.VAR=se.VAR.BRENT;
%Equal weights
for Nmodel=1:6
    for Nprice=1:3
     if Nmodel==1
        K_F.equal.(PriceName{Nprice})=  Forecasts.(ModelName{Nmodel}).(PriceName{Nprice});
     else
        K_F.equal.(PriceName{Nprice})=K_F.equal.(PriceName{Nprice})+Forecasts.(ModelName{Nmodel}).(PriceName{Nprice});
     end
    end
end
K_F.equal.WTI=K_F.equal.WTI./6;
K_F.equal.RAC=K_F.equal.RAC./6;
K_F.equal.BRENT=K_F.equal.BRENT./6;
% Recursive weights
%Space for the forecasts
for Nprice=1:3
    K_F.recursive.(PriceName{Nprice})= NaN(312,24);
end
%Combination
for iiii=1:24
    ind=312-iiii+1;
    for Nmodel =1:ind%out-of-sample forecasts
    
    %recursive weights (1*6)
    for Nprice=1:6
        for Nhorizon=1:3
           if Nprice==1
              SE.(Prices{Nhorizon})=  K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii);
           else
              SE.(Prices{Nhorizon})=[SE.(Prices{Nhorizon}) K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii)];
           end
              MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon}),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});
        end
        
    end
    for Nhorizon=1:3
        weights.(Prices{Nhorizon})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        if Nmodel==1
            Weights.recursive.(Prices{Nhorizon}).(Mh{iiii})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        else
            Weights.recursive.(Prices{Nhorizon}).(Mh{iiii})=[Weights.recursive.(Prices{Nhorizon}).(Mh{iiii}); invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}))];
        end
    end
    clear SE
   clear forecasts weights
    end
end

%Rolling weights 12
%Space for the forecasts
for Nhorizon=1:3
    K_F.rolling12.(Prices{Nhorizon})= NaN(312,24);
end
%Combination
for iiii=1:24
    ind=312-iiii+1;
    for Nmodel =1:ind%out-of-sample forecasts
    
    %recursive weights (6*1)
    for Nprice=1:6
        for Nhorizon=1:3
           if Nprice==1
              SE.(Prices{Nhorizon})=  K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii);
           else
              SE.(Prices{Nhorizon})=[SE.(Prices{Nhorizon}) K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii)];
           end
           if Nmodel<12
               MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon}),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});
           else
               MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon})(Nmodel-12+1:end,:),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});     
           end
        end
        
    end
    for Nhorizon=1:3
            weights.(Prices{Nhorizon})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        if Nmodel==1
            Weights.rolling12.(Prices{Nhorizon}).(Mh{iiii})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        else
            Weights.rolling12.(Prices{Nhorizon}).(Mh{iiii})=[Weights.rolling12.(Prices{Nhorizon}).(Mh{iiii}); invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}))];
        end
    end
    clear SE
    clear forecasts weights
    end
end

%Rolling weights 24
%Space for the forecasts
for Nhorizon=1:3
    K_F.rolling24.(Prices{Nhorizon})= NaN(312,24);
end
%Combination
for iiii=1:24
    ind=312-iiii+1;
    for Nmodel =1:ind%out-of-sample forecasts
    
    %recursive weights (6*1)
    for Nprice=1:6
        for Nhorizon=1:3
           if Nprice==1
              SE.(Prices{Nhorizon})=  K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii);
           else
              SE.(Prices{Nhorizon})=[SE.(Prices{Nhorizon}) K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii)];
           end
           if Nmodel<24
               MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon}),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});
           else
               MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon})(Nmodel-24+1:end,:),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});     
           end
        end
        
    end
    for Nhorizon=1:3
        weights.(Prices{Nhorizon})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        if Nmodel==1
            Weights.rolling24.(Prices{Nhorizon}).(Mh{iiii})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        else
            Weights.rolling24.(Prices{Nhorizon}).(Mh{iiii})=[Weights.rolling24.(Prices{Nhorizon}).(Mh{iiii}); invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}))];
        end
    end
    clear SE
    clear forecasts weights
    end
end

%Rolling weights 36
%Space for the forecasts
for Nhorizon=1:3
    K_F.rolling36.(Prices{Nhorizon})= NaN(312,24);
end
%Combination
for iiii=1:24
    ind=312-iiii+1;
    for Nmodel =1:ind%out-of-sample forecasts
    
    %recursive weights (6*1)
    for Nprice=1:6
        for Nhorizon=1:3
           if Nprice==1
              SE.(Prices{Nhorizon})=  K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii);
           else
              SE.(Prices{Nhorizon})=[SE.(Prices{Nhorizon}) K_se.(Prices{Nhorizon}).(ModelName{Nprice})(1:Nmodel,iiii)];
           end
           if Nmodel<36
               MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon}),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});
           else
               MSE.(Prices{Nhorizon})=mean(SE.(Prices{Nhorizon})(Nmodel-36+1:end,:),1);
               invMSE.(Prices{Nhorizon})=1./MSE.(Prices{Nhorizon});     
           end
        end
        
    end
    for Nhorizon=1:3
        weights.(Prices{Nhorizon})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        if Nmodel==1
            Weights.rolling36.(Prices{Nhorizon}).(Mh{iiii})=invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}));
        else
            Weights.rolling36.(Prices{Nhorizon}).(Mh{iiii})=[Weights.rolling36.(Prices{Nhorizon}).(Mh{iiii}); invMSE.(Prices{Nhorizon})./sum(invMSE.(Prices{Nhorizon}))];
        end
    end
    clear SE
    clear forecasts weights
    end
end
% names of different combinations
CombNames=fieldnames(K_F);
for Nprice=2:5
    for Nmodel=1:3
        for Nhorizon=1:24
            initial_w=ones(Nhorizon+6,6).*1/6;
            Weights.(CombNames{Nprice}).(Prices{Nmodel}).(Mh{Nhorizon})=[initial_w;...
                Weights.(CombNames{Nprice}).(Prices{Nmodel}).(Mh{Nhorizon})];
            Weights.(CombNames{Nprice}).(Prices{Nmodel}).(Mh{Nhorizon})=...
                Weights.(CombNames{Nprice}).(Prices{Nmodel}).(Mh{Nhorizon})(1:end-Nhorizon-5,:);
        end
    end
end
% Combination
for iiii=1:24
    ind=312-iiii+1;
    for Nmodel =1:ind%out-of-sample forecasts
       %6*1 forecasts
       for Nhorizon=1:3
        for Nprice=1:6
        
           if Nprice==1
              forecasts.(Prices{Nhorizon})= ...
                  K_forecasts.(Prices{Nhorizon}).(ModelName{Nprice})(Nmodel,iiii);
           else
              forecasts.(Prices{Nhorizon})=[forecasts.(Prices{Nhorizon});...
                  K_forecasts.(Prices{Nhorizon}).(ModelName{Nprice})(Nmodel,iiii)] ;
           end
           
        end
      %combination
         for nm=2:5
            K_F.(CombNames{nm}).(Prices{Nhorizon})(Nmodel,iiii)=...
                Weights.(CombNames{nm}).(Prices{Nhorizon}).(Mh{iiii})(Nmodel,:)*...
                forecasts.(Prices{Nhorizon});
         end
        
       end

    end
end
%==========================================================================


clearvars -except K_F
save Combined_forecasts 
