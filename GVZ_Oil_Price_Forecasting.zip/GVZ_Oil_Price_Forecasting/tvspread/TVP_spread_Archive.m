clear all;
clc;
warning('off','all')
                                                                   
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});                                                                            

load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision    %Variables for forecasts
%Variables for forecasts
CPI_AC=[nan(546,11) CPI];
RAC_WTI=[nan(546,11) RAC];
WTI=[nan(546,11) WTI];
spotheat=heating_spot;  % 1986.7-2018.06: spot price for heating oil 
spotgas=gasoline_spot;  % 1986.7-2018.06: spot price for gasoline

clearvars -except RAC_WTI CPI_AC WTI BRENT spotheat spotgas Choise_revision Mh
nburn=5000;  % number of burn-in draws (to be discarded)\\tsclient\F
% SELECT FORECAST HORIZON: h=1 to 24
for h=1:24
    tic
    parfor j=12:size(CPI_AC,2)-6-h % Adjust for evaluation period 1992M1 to 2017M12
        %Save density forecasts
        [ TV_density_WTI(:,j-11),TV_density_RAC(:,j-11),...
            TV_density_BRENT(:,j-11)] =...
            TVspread_Main( CPI_AC,WTI, RAC_WTI,BRENT,...
                    spotheat,spotgas,j,h,nburn);
    end
    toc
    %Save point forecast
    TVforecasts.(Mh{h}).WTI=mean(TV_density_WTI,1)';
    TVforecasts.(Mh{h}).RAC=mean(TV_density_RAC,1)';
    TVforecasts.(Mh{h}).BRENT=mean(TV_density_BRENT,1)';
    clear TV_density_WTI TV_density_RAC TV_density_BRENT
    %Save into file for collection


end%End forecast horizons
Savename= strcat('TVspread_Forecasts');
save(Savename, 'TVforecasts')


    
    