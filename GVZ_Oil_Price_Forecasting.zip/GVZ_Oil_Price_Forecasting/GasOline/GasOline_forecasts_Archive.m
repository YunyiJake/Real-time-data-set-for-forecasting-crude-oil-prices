clear all;
clc;
warning('off','all')
%Giving name for different forecasting horizons                                                                   
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});                                                                            

    %Load data
    %Loading vintage real time data with different revision assumptions
    load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision
    %Variables for forecasts
    CPI_AC=[nan(546,11) CPI];
    RAC_WTI=[nan(546,11) RAC];
    WTI=[nan(546,11) WTI];
    spotheat=heating_spot;  % 1986.7-2018.06: spot price for heating oil 
    spotgas=gasoline_spot;  % 1986.7-2018.06: spot price for gasoline
    clearvars -except RAC_WTI CPI_AC WTI BRENT spotgas Mh Choise_revision
for h=1:24
% Basic parameters
ind=228;                                                                   % Indicates length of intial real-time sample (up to 1991.12)
for jx=12:size(CPI_AC,2)-6-h % Adjust for evaluation period 1991:12 to 2017:12
     tic
    % Create data in column format 
    rpo=100*WTI(1:ind,jx)./CPI_AC(1:ind,jx);                               % Real oil price (nominal WTI for imports deflated by US CPI)
    yy=rpo(2:end,1);
        
    rac=100*RAC_WTI(1:ind,jx)./CPI_AC(1:ind,jx);                           % Real oil price (nominal RAC for imports deflated by US CPI)
    yy1=rac(2:end,1);
    
    brent=100*BRENT(1:ind,jx)./CPI_AC(1:ind,jx);                           % Real oil price (nominal Brent for imports deflated by US CPI)
    yy2=brent(2:end,1);    
    t=length(yy1); 
    
    % Define regressors for 1986.7+ in terms of dollars/barrel prices
    spotgasrt=log(spotgas(228-66+1:ind,:)*0.42); 
    spotoilrt=log(WTI(228-66+1:ind,end));
    spotoilrt1=log(BRENT(228-66+1:ind,end)); 
    gasspreadrt=spotgasrt-spotoilrt; 
    
    inflrt=log(CPI_AC(228-66+2:ind,jx))-log(CPI_AC(228-66+1:ind-1,jx)); 

    % Generate h-step ahead Gasoline-based forecasts  
    yy=[yy; zeros(h,1)];
    yy1=[yy1; zeros(h,1)];
    yy2=[yy2; zeros(h,1)];
    YY=spotoilrt(h+1:end,1)-spotoilrt(1:end-h,1);
    YY1=spotoilrt1(h+1:end,1)-spotoilrt1(1:end-h,1);
    XX=[gasspreadrt(1:end-h,1)];
    %OLS estimation
    results=ols1(YY,XX);                                                   % OLS forecasts
    results1=ols1(YY1,XX);

    bb=results.bhatols;
    bb1=results1.bhatols;
    % Forecasts
    Fmat(jx-12+1,1)=yy(t,1)*exp(bb*gasspreadrt(end,1)-...
        ((1+mean(inflrt))^h-1));
    Fmat1(jx-12+1,1)=yy1(t,1)*exp(bb*gasspreadrt(end,1)-...
        ((1+mean(inflrt))^h-1));
    Fmat2(jx-12+1,1)=yy2(t,1)*exp(bb1*gasspreadrt(end,1)-...
        ((1+mean(inflrt))^h-1));


    
    % Update index for recursive estimation
    ind=ind+1;
end

% Svaing point forecasts 
GasolineForecasts.(Mh{h}).WTI=Fmat;
GasolineForecasts.(Mh{h}).RAC=Fmat1;
GasolineForecasts.(Mh{h}).BRENT=Fmat2;
clear Fmat Fmat1 Fmat2 bhat
toc
end

Savename= strcat('GasolineForecasts');
save (Savename,'GasolineForecasts')






















