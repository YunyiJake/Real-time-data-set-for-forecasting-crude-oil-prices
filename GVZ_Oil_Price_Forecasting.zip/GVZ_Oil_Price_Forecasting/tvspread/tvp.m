function [ Results, Forecasts, Mse_future,Se_future,Se_RW ] = tvp( data,WTI, Brent, RAC, RAC_imp, APSP, Dubai,heat,gas,cpi,PriceName)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
for h=1:24
    rand('seed',1234)
    randn('seed',1234)
 % WTI or Brent
 name=data;
 %Names of different oil prices
 PriceName=PriceName;
 %6 prices
 WTI=WTI;
 Brent=Brent;
 RAC=RAC;
 RAC_imp=RAC_imp;
 APSP=APSP;
 Dubai=Dubai;
 %CPI
 CPI_v04m12_v15m12_194801_201512=cpi;
 % gas and heating oil
 spotheat=heat;
 spotgas=gas;
 %Save different forecasting horizon as name
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});
% Basic parameters
ind=min(sum(~isnan(name(:,1))),sum(~isnan(spotheat(:,1)))); % Indicates length of intial real-time sample (up to 2004M12)
nburn=5000;  % number of burn-in draws (to be discarded)
%Adjust the length of all variables according to the shortest data set
CPI=CPI_v04m12_v15m12_194801_201512(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
name=name(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
spotheat=spotheat(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
spotgas=spotgas(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
% 6 prices
WTI=WTI(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
if sum(~isnan(Brent(:,1))) < ind
   b=size(Brent,2);
   Brent=[NaN(ind-sum(~isnan(Brent(:,1))),size(Brent,2)); Brent];
else
Brent=Brent(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
end
clear b
RAC=RAC(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
RAC_imp=RAC_imp(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
APSP=APSP(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);
Dubai=Dubai(end-min(sum(~isnan(name(:,end))),...
    sum(~isnan(spotheat(:,end))))+1:end,:);

%forecasts
for jx=1:size(CPI_v04m12_v15m12_194801_201512,2)-1-h % Adjust for evaluation period 2005M1 to 2015M12
     tic
    % Create data in column format 
    rpo=100*WTI(1:ind,jx)./CPI(1:ind,jx+1);  % Real oil price (nominal WTI for imports deflated by US CPI)
    yy1=rpo(2:end,1);
    rpo=100*Brent(1:ind,jx)./CPI(1:ind,jx+1);  % Real oil price (nominal Brent for imports deflated by US CPI)
    yy2=rpo(2:end,1);
    rpo=100*RAC(1:ind,jx)./CPI(1:ind,jx+1);  % Real oil price (nominal RAC for imports deflated by US CPI)
    yy3=rpo(2:end,1);
    rpo=100*RAC_imp(1:ind,jx)./CPI(1:ind,jx+1);  % Real oil price (nominal RAC_imp for imports deflated by US CPI)
    yy4=rpo(2:end,1);
    rpo=100*APSP(1:ind,jx)./CPI(1:ind,jx+1);  % Real oil price (nominal APSP for imports deflated by US CPI)
    yy5=rpo(2:end,1);
    rpo=100*Dubai(1:ind,jx)./CPI(1:ind,jx+1);  % Real oil price (nominal Dubai for imports deflated by US CPI)
    yy6=rpo(2:end,1);
    t=length(yy1);  
    
    % Define regressors for 1986.7+ in terms of dollars/barrel prices
    spotheatrt=log(spotheat(228-66+1:ind,:)*0.42); 
    spotgasrt=log(spotgas(228-66+1:ind,:)*0.42); 
    spotoilrt=log(name(228-66+1:ind,end)); 
    heatspreadrt=spotheatrt(:,jx)-spotoilrt;
    gasspreadrt=spotgasrt(:,jx)-spotoilrt; 
    
    inflrt=log(CPI(228-66+2:ind,jx+1))-log(CPI(228-66+1:ind-1,jx+1));  
      
    % Create ex post-revised real price of oil (last vintage in file)
        x1=100*WTI(1:ind+h,end)./CPI(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
    x.x1=x1(2:end,1);
        x2=100*Brent(1:ind+h,end)./CPI(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
    x.x2=x2(2:end,1);
        x3=100*RAC(1:ind+h,end)./CPI(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
    x.x3=x3(2:end,1);
        x4=100*RAC_imp(1:ind+h,end)./CPI(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
    x.x4=x4(2:end,1);
        x5=100*APSP(1:ind+h,end)./CPI(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
    x.x5=x5(2:end,1);
        x6=100*Dubai(1:ind+h,end)./CPI(1:ind+h,end);     % Real oil price (nominal RAC for imports deflated by US CPI)
    x.x6=x6(2:end,1);
    x_name=fieldnames(x);
 
    % Generate h-step ahead futures-based forecast  
    yy1=[yy1; zeros(h,1)];
    yy2=[yy2; zeros(h,1)];
    yy3=[yy3; zeros(h,1)];
    yy4=[yy4; zeros(h,1)];
    yy5=[yy5; zeros(h,1)];
    yy6=[yy6; zeros(h,1)];    
    YY=spotoilrt(h+1:end,1)-spotoilrt(1:end-h,1); 
    XX=[heatspreadrt(1:end-h,1) gasspreadrt(1:end-h,1)];
      
    %alpha and beta time-varying
    [bhat,q,r]=estimate_bt_final(YY,XX,nburn);
    clear XX YY
       
   
     yyy1=zeros(size(bhat,3),1);
     yyy2=zeros(size(bhat,3),1);
     yyy3=zeros(size(bhat,3),1);
     yyy4=zeros(size(bhat,3),1);
     yyy5=zeros(size(bhat,3),1);
     yyy6=zeros(size(bhat,3),1);
     
       
     for jj=1:size(bhat,3)
         bb=squeeze(bhat(:,end,jj));
         for jy=2:h
             bb(:,jy)=bb(:,jy-1)+real(sqrtm(q(:,:,jj)))*randn(size(bhat,1),1);
         end
        yyy1(jj,1)=yy1(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                             +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
        yyy2(jj,1)=yy2(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                             +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
        yyy3(jj,1)=yy3(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                             +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
        yyy4(jj,1)=yy4(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                             +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
        yyy5(jj,1)=yy5(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                             +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
        yyy6(jj,1)=yy6(t,1)*exp(bb(1,h)*heatspreadrt(end,1) ...
                             +bb(2,h)*gasspreadrt(end,1)+(randn(1,1)*sqrt(r(jj,1)))-((1+mean(inflrt))^h-1));
        clear bb
     end
     yy.yy1(t+h,1)=mean(yyy1,1);
     yy.yy2(t+h,1)=mean(yyy2,1);
     yy.yy3(t+h,1)=mean(yyy3,1);
     yy.yy4(t+h,1)=mean(yyy4,1);
     yy.yy5(t+h,1)=mean(yyy5,1);
     yy.yy6(t+h,1)=mean(yyy6,1);
     y_name=fieldnames(yy);
    %Evaluate h-step ahead futures forecast
    for i=1:6
    se.(PriceName{i})(jx,1)=(yy.(y_name{i})(t+h,1)-x.(x_name{i})(t+h,1))^2;     % Squared forecast error
    % Keep track of forecasts for forecast combination
    Fmat.(PriceName{i})(jx,1)=yy.(y_name{i})(t+h,1);    % Futures forecast
    %Evaluate h-step ahead RW forecast
    se.(PriceName{i})(jx,2)=(yy.(y_name{i})(t,1)-x.(x_name{i})(t+h,1))^2;     % Squared forecast error
    end    
    clear t yy
    % Update index for recursive estimation
    ind=ind+1; toc
end

% Evaluate real-time recursive forecast accuracy
for i=1:6
Se_future.(PriceName{i}).(Mh{h})=se.(PriceName{i})(:,1);
Se_RW.(PriceName{i}).(Mh{h})=se.(PriceName{i})(:,2);

%mse=mean(se);
%For missing value
notNaN = ~isnan(se.(PriceName{i}));
T =sum(notNaN);
se.(PriceName{i})(~notNaN) = 0;
SUM_se.(PriceName{i})=sum(se.(PriceName{i}));
mse.(PriceName{i})=SUM_se.(PriceName{i})./T;
disp('Horizon')
disp(h)
disp((PriceName{i}))
disp('Real-time recursive PMSE Ratio for oil futures price at this horizon')
disp(mse.(PriceName{i})(1)/mse.(PriceName{i})(2))

Results.(PriceName{i})(h,1)=h;
Results.(PriceName{i})(h,2)=mse.(PriceName{i})(1)/mse.(PriceName{i})(2);
Forecasts.(PriceName{i})(1:size(Fmat.(PriceName{i}),1),h)=Fmat.(PriceName{i});   %contains forecasts for forecast combination
Mse_future.(PriceName{i})(h,1)=h;
Mse_future.(PriceName{i})(h,2)=mse.(PriceName{i})(1);
end
clear yy rpo se mse Fmat x t SUM_se

end

end



