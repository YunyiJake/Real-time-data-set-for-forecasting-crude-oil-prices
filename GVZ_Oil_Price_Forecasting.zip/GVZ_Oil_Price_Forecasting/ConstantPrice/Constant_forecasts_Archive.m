clear all;
clc;
warning('off','all')
%Giving name for different forecasting horizons                                                                   
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});                                                                            

load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision
%Variables for forecasts
CPI_AC=[nan(546,11) CPI];
RAC_WTI=[nan(546,11) RAC];
WTI=[nan(546,11) WTI];    
clearvars -except RAC_WTI CPI_AC WTI BRENT Mh Choise_revision
    
%Forecasts
for h=1:24
    tic 
% Basic parameters
ind=228; % Indicates length of intial real-time sample
for jx=12:size(CPI_AC,2)-6-h % Adjust for evaluation period 1992:01 to 2017:12
     
    % Create data in column format 
    rpo1=100*WTI(1:ind,jx)./CPI_AC(1:ind,jx);                              % Real oil price (nominal WTI for imports deflated by US CPI)
    rpo2=100*RAC_WTI(1:ind,jx)./CPI_AC(1:ind,jx);                          % Real oil price (nominal RAC for imports deflated by US CPI)
    rpo3=100*BRENT(1:ind,jx)./CPI_AC(1:ind,jx);                            % Real oil price (nominal Brent for imports deflated by US CPI)
    yy1=rpo1(2:end,1);
    yy2=rpo2(2:end,1);
    yy3=rpo3(2:end,1);
    t=length(yy2); 
    
     
   % Keep track of forecasts for forecast combination
    Fmat1(jx-12+1,1)=yy1(t,1);  
    Fmat2(jx-12+1,1)=yy2(t,1);  
    Fmat3(jx-12+1,1)=yy3(t,1);
    clear t yy1 yy2 yy3
    
    % Update index for recursive estimation
    ind=ind+1;
end
% Svaing point forecasts 
ConstantForecasts.(Mh{h}).WTI=Fmat1;   %contains forecasts for forecast combination
ConstantForecasts.(Mh{h}).RAC=Fmat2;
ConstantForecasts.(Mh{h}).BRENT=Fmat3;
clear yy rpo se mse Fmat x t
toc
end

Savename= strcat('Constant_forecasts');
save (Savename,'ConstantForecasts')
