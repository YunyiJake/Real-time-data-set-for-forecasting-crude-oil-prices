function [B_post,Q_post,R_post] = estimate_bt_final(y,x,nburn)

k   = size(x,2);  % number of regressors
t   = size(y,1)-30;

% Set priors and initial states 
% training sample
xx=x(1:30,:);
yy=y(1:30,1);
bols   = (xx'*xx)\(xx'*yy);
sigols = ((yy-xx*bols)'*(yy-xx*bols))/(30-k);
B00    = bols;  
P00    = 0.1*sigols*inv(xx'*xx);   


% starting values for Gibbs sampler
r = 0.0005;
q = 3.5e-04*P00;

% priors 
% Assume     p(Q) ~ IW(Q0,t0)
%            p(R) ~ IG(R0,t0)
tq0 = 30;      % degrees of freedom (shape parameter)
Q0 = tq0*q;    % variance of error on state equation (scale parameter)

t0 = 20;
R0 = 0.0001;   % variance of error on observation equation (scale parameter)

% parameters for Gibbs sampler
nkeep   = 1000;
n       = nkeep+nburn;

% allocate 
B_post  = zeros(k,t,nkeep);   % 3D storage object
R_post  = zeros(nkeep,1);
Q_post  = zeros(k,k,nkeep);

%Gibbs sampler algorithm
for rep=1:n
    
    % Step 1: generate B_{t} conditional on R and Q 
    % use Kalman filter and Carter-Kohn recursions
    [beta res] = filterb_k(y(31:end,1),x(31:end,:),B00',P00,q,r,k);
    
    % Step 2: generate R conditional on B
    t1 = t0+t;
    R1 = R0+res'*res;

    z = randn(t1,1);
    a = z'*z;
    r = R1/a;
    clear t1 R1
    
    % Step 3: generate Q conditional on B
    beta=beta';
    tq1 = tq0+t;       %posterior degrees of freedom
    Q1 = Q0+(beta(:,2:end)-beta(:,1:end-1))*(beta(:,2:end)-beta(:,1:end-1))';
    PS = real(sqrtm(inv(Q1)));
    u = randn(k,tq1);
    q = inv(PS*(u*u')*PS');
    
    clear tq1 Q1
    
    if rep>nburn
        B_post(:,:,rep-nburn)  = beta;
        R_post(rep-nburn,:)  = r;
        Q_post(:,:,rep-nburn)  = q;
    end
end