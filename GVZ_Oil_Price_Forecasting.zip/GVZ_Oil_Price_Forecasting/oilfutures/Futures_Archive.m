clear all;
clc;
warning('off','all')

%Giving name for different forecasting horizons                                                                   
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});                                                                            
        
load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision    %Variables for forecasts
CPI_AC=[nan(546,11) CPI];
RAC_WTI=[nan(546,11) RAC];    
WTI=[nan(546,11) WTI];
fut=[nan(226,24); WTI_F_backcasts_KF];%WTI
fut1=[nan(226,24); BRENT_F_backcasts_KF];%BRENT
fut2=[nan(226,24);Wiki_futures.Settle];%Wiki futures settle price
clearvars -except RAC_WTI CPI_AC WTI BRENT fut fut1 fut2 Mh Choise_revision Wiki
    
for h=1:24
 tic   
% Basic parameters
ind=228;                                                                   % Indicates length of intial real-time sample (up to 1991.12)
    

for jx=12:size(CPI_AC,2)-6-h                                               % Adjust for evaluation period 1991:12 to 2017:12
     
    % Create data in column format 
    rpo=100*WTI(1:ind,jx)./CPI_AC(1:ind,jx);                               % Real oil price (nominal WTI for imports deflated by US CPI)
    yy=rpo(2:end,1);
    % Create data in column format 
    rpo1=100*RAC_WTI(1:ind,jx)./CPI_AC(1:ind,jx);                          % Real oil price (nominal RAC for imports deflated by US CPI)
    yy1=rpo1(2:end,1);
    % Create data in column format 
    rpo2=100*BRENT(1:ind,jx)./CPI_AC(1:ind,jx);                            % Real oil price (nominal Brent for imports deflated by US CPI)
    yy2=rpo2(2:end,1);
    
    futrt=log(fut(2:ind,:));
    futrt1=log(fut1(2:ind,:));
    futrt2=log(fut2(2:ind,:));
    inflrt=log(CPI_AC(228-66+2:ind,jx))-log(CPI_AC(228-66+1:ind-1,jx));  
      
    poilrt=log(WTI(2:ind,jx));                                             % average price
    poilrt1=log(BRENT(2:ind,jx));                                          % average price
    
    t=length(yy); 

    % Generate h-step ahead futures-based forecast  
    Fmat(jx-12+1,1)= yy(t,1)*(1+futrt(t-1,h)-poilrt(t,1)-((1+mean(inflrt))^h-1));

    Fmat1(jx-12+1,1)= yy1(t,1)*(1+futrt2(t-1,h)-poilrt(t,1)-((1+mean(inflrt))^h-1)); 

    Fmat2(jx-12+1,1)= yy2(t,1)*(1+futrt1(t-1,h)-poilrt1(t,1)-((1+mean(inflrt))^h-1)); 

    clear t yy yy1 yy_f yy1_f yy2_f r1 r2 r3 yyy yyy1 yyy2
    
    % Update index for recursive estimation
    ind=ind+1;
end

% Svaing point forecasts 
Future_forecasts.(Mh{h}).WTI=Fmat;
Future_forecasts.(Mh{h}).RAC=Fmat1;
Future_forecasts.(Mh{h}).BRENT=Fmat2;
clear yy yy1 yy2 rpo rpo1 rpo2 se mse Fmat Fmat1 x t Fmat2
toc
end

Savename= strcat('Future_Forecasts');
save (Savename,'Future_forecasts')


