clear all;
clc;
warning('off','all')

%Giving name for different forecasting horizons                                                                   
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});                                                                            

%Load data
load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision    %Variables for forecasts
CPI_AC=[nan(546,11) CPI];
RAC_WTI=[nan(546,11) RAC];
WTI=[nan(546,11) WTI];    
raw=CRB_av; % 1973:01-2018:06
clearvars -except RAC_WTI CPI_AC WTI raw BRENT Mh Choise_revision

% SELECT FORECAST HORIZON: h=1 to 24
for h=1:24

% Load real-time datasets
% Basic parameters
ind=228; % Indicates length of intial real-time sample (up to 1991.12)

for jx=12:size(CPI_AC,2)-6-h  % Adjust for evaluation period 1991:12 to 2017:12
       
    % Create data in column format 
    rpo=100*WTI(1:ind,jx)./CPI_AC(1:ind,jx);     % Real oil price (nominal WTI deflated by US CPI)
    yy1=rpo(2:end,1);

    rpo2=100*RAC_WTI(1:ind,jx)./CPI_AC(1:ind,jx);     % Real oil price (nominal RAC for imports deflated by US CPI)
    yy2=rpo2(2:end,1);

    rpo3=100*BRENT(1:ind,jx)./CPI_AC(1:ind,jx);     % Real oil price (nominal Brent for imports deflated by US CPI)
    yy3=rpo3(2:end,1);

    rawrt=log(raw(2:ind,1));     
    inflrt=log(CPI_AC(228-66+2:ind,jx))-log(CPI_AC(228-66+1:ind-1,jx)); 
    [t,q]=size(yy2); 

         
    % Generate h-step ahead based on the spot price of industrial raw materials forecast  
    yy1=[yy1; zeros(h,1)];
    for i=1:h
       yy1(t+i,1)= yy1(t,1)*(1+rawrt(t,1)-rawrt(t-h,1)-((1+mean(inflrt))^i-1));       
    end
    yy2=[yy2; zeros(h,1)];
    for i=1:h
       yy2(t+i,1)= yy2(t,1)*(1+rawrt(t,1)-rawrt(t-h,1)-((1+mean(inflrt))^i-1));       
    end  
    yy3=[yy3; zeros(h,1)];
    for i=1:h
       yy3(t+i,1)= yy3(t,1)*(1+rawrt(t,1)-rawrt(t-h,1)-((1+mean(inflrt))^i-1));       
    end  
         

    % Keep track of forecasts for forecast combination
    Fmat(jx-12+1,1)=yy1(t+h,1);  
    Fmat2(jx-12+1,1)=yy2(t+h,1);  
    Fmat3(jx-12+1,1)=yy3(t+h,1);  

    clear t yy1 yy2 yy3
    
    % Update index for recursive estimation
    ind=ind+1;
end

PCOM_forecast.(Mh{h}).WTI=Fmat;
PCOM_forecast.(Mh{h}).RAC=Fmat2;
PCOM_forecast.(Mh{h}).BRENT=Fmat3;
clear Fmat Fmat2 Fmat3 yy1_f yy2_f yy3_f
end

Savename= strcat('PCOM_Forecasts');
save (Savename,'PCOM_forecast')


