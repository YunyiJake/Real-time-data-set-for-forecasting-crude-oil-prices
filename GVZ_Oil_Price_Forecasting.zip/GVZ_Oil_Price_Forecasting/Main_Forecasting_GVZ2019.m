         %Garratt, A., Vahey, S.P. and Zhang, Y., 2019. 
         %Real-time forecast combinations for the oil price. 
         %Journal of Applied Econometrics, 34(3), pp.456-462.


%========================Data description==================================
% Rows: T (starting in 1973:01)
% Columns: point in real time (1991:12 to 2018:06)
% RAC_WTI      %WTI nowcast of the nominal refiner acquistion cost of imported crude oil
% WTI          %WTI spot price data (average)
% CPI_AC       %average change nowcast of US CPI
% spotgas      %1986.7-2018.06: spot price for gasoline
% spotheat     %1986.7-2018.06: spot price for heating oil
% fut          %WTI FUTURES FOR H=1 TO 24 FROM BLOOMBERG
% fut1         %BRENT FUTURES FOR H=1 TO 24 FROM BLOOMBERG
% CRB_av       %Price of non-oil industrial raw materials
% QO_AC        %average change nowcast of world oil production
% USinv_AC     %average change nowcast of US crude oil inventories
% ratio_NC     %no change nowcast of the ratio between OECD and US petroleum inventories with Baumeister method
% rea          %normalized BDI/Kilian (AER 2009) shipping index 
% rea_Hamilton %Baumeister and Hamilton OECD+6 industrial productions 
%==========================================================================

% NOTICE:
% -------
% We thanks Baumeister and Kilian supplied some basic codes.
%
% Permission is hereby granted to use this code freely for academic
% purposes only, provided that the paper is duly cited as:
%
%Garratt, A., Vahey, S.P. and Zhang, Y., (2019) Real-time forecast combinations
%for the oil price. Journal of Applied Econometrics, 34(3), pp.456-462.
%
%
% Any other use of this code, particularly for comercial purposes, is
% strictly prohibited without the prior written consent of the authors.
% Furthermore, this code comes without technical support of any kind.  It
% is expected to reproduce the results reported in the paper.  However,
% beware that the notation may not the match text.  
%
% Under no circumstances will the authors be held responsible for any use
% (or misuse) of this code in any way.  If you do not agree to the above,
% you do not have permission to use this code.


% Add paths
currentFolder = pwd;
addpath(genpath(currentFolder));

%% Specification forecasts
% Constant 
Constant_forecasts_Archive

% Gasline
GasOline_forecasts_Archive

% Futures
Futures_Archive

% Comdity price
Pcom_Archive

% TVP spread
TVP_spread_Archive

% Oil market VAR
VAR_Archive

%% Combination forecasts
Combine_Archive






