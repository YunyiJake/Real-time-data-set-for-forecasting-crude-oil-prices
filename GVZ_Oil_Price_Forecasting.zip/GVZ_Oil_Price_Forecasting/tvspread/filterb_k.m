function [B2 res] = filterb_k(y,x,B00,P00,Q,R,n)
% 
% uses Kalman filter and smoother a la Carter Kohn 1994 to 
% simulate the state vector of a linear state space model conditional
% on the hyperparameters of the model
%
% Model
% observation eq.:          y_{t} = B_{t} * y_{t-1} + v_{t} 
% transition (state) eq.:   B_{t} = B_{t-1} + e_{t} 
% 
%                           v_{t} ~ N(0,R)
%                           e_{t} ~ N(0,Q)
%
% Output:
% B2    B_{t} draw
% res   residuals y-x*B2

% Input: 
% y     LHS variables. t x 1
% x     RHS variables incl constant, lags of y. t x (k x l +1)
% B00   initial mean of state
% P00   initial variance of state
% Q     see model above
% R     see model above
% k     number of RHS variables including constant if any
% l     number of lags if any


% KALMAN FILTER

t   = size(y,1);
f   = eye(n);        % random walk
mu  = zeros(n,1);    % without drift
Btt = zeros(t,n);
Ptt = zeros(t,n,n);

% basic filter (forward recursions): from beginning to end of sample
for i=1:t
    xx          = x(i,:);
    % PREDICTION
    B10         = mu+f*B00';         %forecast of beta (based on state eq.)
    P10         = f*P00*f'+Q;        %variance of beta
    yhat        = xx*B10;            %forecast of y (based on observation eq.)
    eta         = y(i,:)-yhat;       %forecast error for y 
    feta        = (xx*P10*xx')+R;    %variance of forecast error of y
    % UPDATING (with info in forecast error)
    K           = (P10*xx')*inv(feta);      %Kalman gain
    B11         = (B10+K*eta')';            %update of beta
    P11         = P10-K*(xx*P10);           %update of variance of beta
    Btt(i,:)    = B11;
    Ptt(i,:,:)  = P11;
    B00 = B11;        
    P00 = P11;
end


% Kalman smoother (backward recursions)

    B2   = zeros(t,n);  %stores smoothed estimates of beta
    wa   = randn(t,n);
    res  = zeros(t,1);        %stores residual of observation eq.
    i=t;                      %starts from T (last observation)
    Pt           = squeeze(Ptt(i,:,:));
    B2(i,:)      = Btt(i,:)+wa(i,:)*real(sqrtm(Pt));   %draw beta from normal N(Btt,Ptt)
    res(i,:)     = y(i,:)-x(i,:)*B2(i,:)';   
    
    for i=t-1:-1:1
        Pt       = squeeze(Ptt(i,:,:));
        
        % derive the MEAN
        Bm       = Btt(i,:)+(Pt*f'*inv(f*Pt*f'+Q)*(B2(i+1,:)-Btt(i,:)*f'-mu')')';
        
        % derive the VARIANCE
        Pm       = Pt-Pt*f'*inv(f*Pt*f'+Q)*f*Pt;
        
        % DRAW BETA from this distribution
        B2(i,:)  = Bm+wa(i,:)*real(sqrtm(Pm));
        res(i,:) = y(i,:)-x(i,:)*B2(i,:)';
        
    end

