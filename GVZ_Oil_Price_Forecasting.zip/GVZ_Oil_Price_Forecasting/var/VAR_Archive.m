clear all;
clc;
warning('off','all')

%Giving name for different forecasting horizons                                                                   
Mh=genvarname({'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9',...
    'h10', 'h11', 'h12', 'h13', 'h14', 'h15', 'h16', 'h17', 'h18', 'h19',...
    'h20', 'h21', 'h22', 'h23', 'h24'});                                                                            

%Load data
load Realvintage_dataSet_WITHnowcast_0618_withoutAnnualrevision
%Variables for forecasts
CPI_AC=[nan(546,11) CPI];
RAC_WTI=[nan(546,11) RAC];
WTI=[nan(546,11) WTI];
QO_AC=[nan(546,11) WOIL_production];
USinv_AC=[nan(546,11) crude_oil_ttstocks];
ratio_NC=[nan(546,11) ratio_NC];

Idx_Hamilton=0;%1: Hamilton OECD+6 industrial production
               %0: %Kilian rea
if Idx_Hamilton 
    NEA=100.*[nan(546,11) rea_Hamilton]; 
else
    NEA=100.*[nan(546,11) rea];
end
clearvars -except RAC_WTI CPI_AC WTI QO_AC USinv_AC ratio_NC NEA BRENT Mh windowsize
% SELECT FORECAST HORIZON: h=1 to 24
for h=1:24
tic

% Basic parameters
ind=228; % Indicates length of intial real-time sample (up to 1991:12)
p=12;      % VAR lag order

for jx=12:size(NEA,2)-6-h % Adjust for evaluation period 1992:01 to 2017:12
      
    % Create VAR data in column format 
    qo=lagn(100*log(QO_AC(1:ind,jx)),1);           % World oil production growth
    rpo=log(100*RAC_WTI(1:ind,jx)./CPI_AC(1:ind,jx));     % Real oil price (nominal RAC for imports deflated by US CPI, log)
    oecd_inv=lagn((USinv_AC(1:ind,jx).*ratio_NC(1:ind,jx)),1);   % Proxy for OECD crude oil inventories (nsa), in changes
    US_inv=lagn(log(USinv_AC(1:ind,jx)),1);
    OECD_US=lagn(log(ratio_NC(1:ind,jx)),1);
    rea=lagn(NEA(1:ind,jx),1);
    yy=[qo rea rpo(2:end,1) oecd_inv];
    
    [t,q]=size(yy); 

    % Create ex post-revised real price of oil (last vintage in file)
    x=100*WTI(1:ind+h,end)./CPI_AC(1:ind+h,end);     % Real oil price (nominal WTI deflated by US CPI, no log)
    x=x(2:end,1);
    
    %Estimate UVAR(p) and BVAR(p)
    OLSresults = OLSvar(yy,p,h);
    % Monthly Spread
    spread=WTI(ind,jx)./RAC_WTI(ind,jx); % Most recent monthly spread of WTI price over RAC import price
    spread1=BRENT(ind,jx)./RAC_WTI(ind,jx); % Most recent monthly spread of WTI price over RAC import price    


    % Keep track of forecasts for forecast combination
    Fmat(jx-12+1,1)=spread*exp(OLSresults.forecast(h,3));
    Fmat1(jx-12+1,1)=exp(OLSresults.forecast(h,3));
    Fmat2(jx-12+1,1)=spread1*exp(OLSresults.forecast(h,3));
    % Update index for recursive estimation
    ind=ind+1; 

end

VARforecasts.(Mh{h}).WTI=Fmat;
VARforecasts.(Mh{h}).RAC=Fmat1;
VARforecasts.(Mh{h}).BRENT=Fmat2;
clear Fmat Fmat1 Fmat2
toc
h
end

Savename= strcat('VARforecasts');
save (Savename,'VARforecasts')













